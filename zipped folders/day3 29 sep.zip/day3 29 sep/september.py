def black():
    print("hello from black")
    # some code
    
def white():
    print("hello from white")
    # some code
    
    
def grey():
    print("grey is a mixture of ")
    black()
    white()